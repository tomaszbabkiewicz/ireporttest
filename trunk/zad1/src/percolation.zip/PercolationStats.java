public class PercolationStats {

    // perform T independent computational experiments on an N-by-N grid
    public PercolationStats(int N, int T) {
    }

    // sample mean of percolation threshold
    public double mean() {
        return 0.0;
    }

    // sample standard deviation of percolation threshold
    public double stddev() {
        return 0.0;
    }

    // returns lower bound of the 95% confidence interval
    public double confidenceLo() {
        return 0.0;
    }

    // returns upper bound of the 95% confidence interval
    public double confidenceHi() {
        return 0.0;
    }

    // test client, described below
    public static void main(String[] args) {
    }
}